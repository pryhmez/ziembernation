package com.heyrise.calendarAssessment.components.calendarComponent.core.calendarManagement.rest.resource;


import lombok.Data;

@Data
public class CalendarResource {
    private String id;
    private String name;
}